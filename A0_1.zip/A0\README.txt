About: bst Implementation of lists - As a C++ primer example
Date: feb 11, 2025
Comments: Includes three files -> bst.h, bst.cpp, mainbst.cpp

*** FIRST OPEN THE FOLDER WHERE THESE THREE FILES ARE LOCATED:
    In command prompt:
        cd folder-containing-the-files
        code .
*** 
To compile: g++ mainbst.cpp bst.cpp
To run: ./a 

OR

To compile: g++ mainbst.cpp bst.cpp -o whatevernameyoulike
To run: ./whatevernameyoulike